# NES Manager Notes Checklist (PWA)

This is a Progressive Web App version of the checklist. It supports offline use, auto-save, +Add Row, drag-and-drop, and JSON import/export.

## Deploy on GitHub Pages

1. Create a new repo on GitHub (e.g., `nes-checklist-pwa`).
2. Upload all files in this folder to the repo root (including `index.html`, `manifest.json`, `service-worker.js`, and the `icons/` directory).
3. In the repo, go to **Settings → Pages**.
4. Under **Build and deployment**, set:
   - **Source:** *Deploy from a branch*
   - **Branch:** `main` (or `master`), **/ (root)**
5. Click **Save**. Wait ~1 min for deployment.
6. Your site will be available at: `https://<your-username>.github.io/<repo-name>/`

### Testing the PWA
- Open the URL in your browser.
- On Android (Chrome): Menu → **Add to Home screen**.
- On iPhone (Safari): Share → **Add to Home Screen**.

### Notes
- Ensure you serve over **HTTPS** (GitHub Pages does this for you).
- Keep file paths the same; `manifest.json` and `service-worker.js` are referenced from the root.
- If you move files into a subfolder, update the paths in `index.html` and `service-worker.js` accordingly.
