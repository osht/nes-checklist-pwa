
const CACHE_NAME = 'nes-checklist-v1';
const ASSETS = [
  './NES_Manager_Notes_Checklist_PWA.html',
  './manifest.json',
  './icons/icon-192.png',
  './icons/icon-512.png'
];

self.addEventListener('install', (evt) => {
  evt.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.addAll(ASSETS)));
});
self.addEventListener('activate', (evt) => {
  evt.waitUntil(self.clients.claim());
});
self.addEventListener('fetch', (evt) => {
  evt.respondWith(caches.match(evt.request).then((cached) => cached || fetch(evt.request)));
});
